package com.example.nasamessenger;

public class Message {
    private String user_name, message_id, date_time, employee_code, project_code, message, message_type;

    public Message() {
    }

    public Message(String user_name, String message_id, String date_time, String employee_code, String project_code, String message, String message_type) {
        this.user_name = user_name;
        this.message_id = message_id;
        this.date_time = date_time;
        this.employee_code = employee_code;
        this.project_code = project_code;
        this.message = message;
        this.message_type = message_type;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getMessage_id() {
        return message_id;
    }

    public void setMessage_id(String message_id) {
        this.message_id = message_id;
    }

    public String getDate_time() {
        return date_time;
    }

    public void setDate_time(String date_time) {
        this.date_time = date_time;
    }

    public String getEmployee_code() {
        return employee_code;
    }

    public void setEmployee_code(String employee_code) {
        this.employee_code = employee_code;
    }

    public String getProject_code() {
        return project_code;
    }

    public void setProject_code(String project_code) {
        this.project_code = project_code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessage_type() {
        return message_type;
    }

    public void setMessage_type(String message_type) {
        this.message_type = message_type;
    }
}
