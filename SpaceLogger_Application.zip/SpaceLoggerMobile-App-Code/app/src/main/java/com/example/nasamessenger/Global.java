package com.example.nasamessenger;

public class Global {
    public static int employeeCode;
    public static String projectCode;
    public static String employeeName;
}
