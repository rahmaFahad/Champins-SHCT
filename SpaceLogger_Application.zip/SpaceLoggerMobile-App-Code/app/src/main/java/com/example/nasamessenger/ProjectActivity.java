package com.example.nasamessenger;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.app.VoiceInteractor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ProjectActivity extends AppCompatActivity {
    RecyclerView rvProjects;
    TextView tvUserName;
    String pnames[],pimages[],pcodes[];

    RequestQueue queue;
    StringRequest request;
    ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_project);

        tvUserName = (TextView) findViewById(R.id.name);
        tvUserName.setText(Global.employeeName);

        dialog = new ProgressDialog(this);
        dialog.setMessage("Getting Projects.....");
        dialog.setCancelable(false);

        dialog.show();
        fillProjectNames();
    }

    private void fillProjectNames() {
        String url = "http://10.0.2.2/nasa/readprojectnames.php?Submit1=submit";
        queue = Volley.newRequestQueue(this);
        StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();
                try {
                    JSONObject object = new JSONObject(response);
                    JSONArray array = object.getJSONArray("res");
                    pnames = new String[array.length()];
                    pimages = new String[array.length()];
                    pcodes = new String[array.length()];
                    for(int i=0;i<array.length();i++) {
                        JSONObject object1 = array.getJSONObject(i);
                        pnames[i]=object1.getString("Project_Name");
                        pimages[i]=object1.getString("Project_Image");
                        pcodes[i]=object1.getString("Project_code");
                        //Toast.makeText(getApplicationContext(), object1.getString("Project_Name"), Toast.LENGTH_SHORT).show();
                    }
                    rvProjects = (RecyclerView) findViewById(R.id.rvProjects);
                    ProjectAdapter pa = new ProjectAdapter(ProjectActivity.this, pnames, pimages, pcodes);
                    rvProjects.setAdapter(pa);
                    rvProjects.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                } catch(JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("Error: ",error.toString());
            }
        });
        queue.add(request);
    }

    public void goBack(View view) {
        finish();
    }
}