package com.example.nasamessenger;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class RegistrationActivity extends AppCompatActivity {

    EditText etUserName, etPassword, etEmail, etCode, etMobile;
    //Button btnSignup;
    String susername, spass, semail, secode, smobile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_registration);

        etUserName = (EditText) findViewById(R.id.etUserName);
        etPassword = (EditText) findViewById(R.id.etPassword);
        etEmail = (EditText) findViewById(R.id.etEmail);
        etCode = (EditText) findViewById(R.id.etECode);
        etMobile = (EditText) findViewById(R.id.etMobile);
    }

    public void doSignup(View v) {
        susername = etUserName.getText().toString();
        spass = etPassword.getText().toString();
        semail = etEmail.getText().toString();
        secode = etCode.getText().toString();
        smobile = etMobile.getText().toString();

        String url = "http://10.0.2.2/nasa/saveinfo.php?Text1=" + secode +
                "&Text2=" + susername +
                "&Text3=" + spass +
                "&Text4=" + semail +
                "&Text5=" + smobile +
                "&Submit1=submit";
        //Toast.makeText(this, url, Toast.LENGTH_LONG).show();
        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //Toast.makeText(getApplicationContext(), "Record Added", Toast.LENGTH_LONG).show();
                finish();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
            }
        });
        queue.add(request);
    }
}