package com.example.nasamessenger;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class ChatActivity extends AppCompatActivity {

    RecyclerView rvChats;
    EditText messageBox;

    Message message;
    String pname,pcode;
    String mid[],mdt[],meid[],mpc[],mes[],mesid[];
    TextView tvPName;
    ProgressDialog dialog;
    RequestQueue rq;
    StringRequest sr;

    ChatAdapter adapter;
    ArrayList<Message> alMessages;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_chat);

        messageBox = (EditText) findViewById(R.id.messageBox);

        pname = getIntent().getStringExtra("pname");
        pcode = getIntent().getStringExtra("pcode");
        Global.projectCode=pcode;
        tvPName = (TextView) findViewById(R.id.name);
        tvPName.setText(pname);

        dialog = new ProgressDialog(this);
        dialog.setMessage("Getting Messages.....");
        dialog.setCancelable(false);

        dialog.show();
        alMessages = new ArrayList<>();
        getMessages(pcode);
    }

    private void getMessages(String pcode) {
        String url = "http://10.0.2.2/nasa/readmessages.php?Text1=" +
                pcode +
                "&Submit1=submit";

        rq = Volley.newRequestQueue(getApplicationContext());
        sr = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();
                alMessages.clear();
                if(!response.equals("0")) {
                    try {
                        JSONObject object = new JSONObject(response);
                        JSONArray array = object.getJSONArray("res");

                        for(int i=0;i<array.length();i++) {
                            JSONObject object1 = array.getJSONObject(i);
                            message = new Message(
                                    object1.getString("User_Name"),
                                    object1.getString("message_id"),
                                    object1.getString("date_time"),
                                    object1.getString("employee_code"),
                                    object1.getString("project_code"),
                                    object1.getString("message"),
                                    object1.getString("message_type"));
                            alMessages.add(message);
                            //Toast.makeText(getApplicationContext(), object1.getString("Project_Name"), Toast.LENGTH_SHORT).show();
                        }

                        rvChats = (RecyclerView) findViewById(R.id.rvChats);
                        ChatAdapter ca = new ChatAdapter(ChatActivity.this, alMessages);
                        ca.notifyDataSetChanged();
                        rvChats.setAdapter(ca);
                        rvChats.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                    } catch(JSONException e) {
                        e.printStackTrace();
                    }
                    //Toast.makeText(getApplicationContext(), "chat : " + response, Toast.LENGTH_LONG).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("Chat Activity Error: ",error.toString());
            }
        });
        rq.add(sr);
    }

    public void sendMessage(View view) {
        String messageText = messageBox.getText().toString();

        Date dd = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        SimpleDateFormat mid = new SimpleDateFormat("MMddHHmmss",Locale.getDefault());
        String sdate = sdf.format(dd);
        String smid = mid.format(dd);

        Toast.makeText(ChatActivity.this, smid,Toast.LENGTH_LONG).show();
        Message message = new Message(Global.employeeName, smid, sdate, Global.employeeCode+"", Global.projectCode, messageText, "1");

        String url="http://10.0.2.2/nasa/savemessage.php?Text1=" +
                smid +
                "&Text2=" +
                sdate +
                "&Text3=" +
                (Global.employeeCode+"") +
                "&Text4=" +
                Global.projectCode +
                "&Text5=" +
                messageBox.getText().toString() +
                "&Text6=" +
                "1" +
                "&Submit1=submit";

        RequestQueue rq = Volley.newRequestQueue(getApplicationContext());
        StringRequest sr = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                alMessages.add(message);
                messageBox.setText("");

                adapter = new ChatAdapter(ChatActivity.this, alMessages);
                adapter.notifyDataSetChanged();
                rvChats.setAdapter(adapter);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) { }
        });
        rq.add(sr);
    }

    public void goBackProjects(View view) {
        finish();
    }
}