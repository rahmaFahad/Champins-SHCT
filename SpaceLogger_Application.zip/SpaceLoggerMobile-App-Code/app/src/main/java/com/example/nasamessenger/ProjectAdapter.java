package com.example.nasamessenger;

import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Base64;

public class ProjectAdapter extends RecyclerView.Adapter<ProjectAdapter.MyViewHolder> {
    String[] data,imgs, pcodes;
    Context context;

    public ProjectAdapter(Context context, String[] data, String[] imgs, String[] pcodes) {
        this.context = context;
        this.data = data;
        this.imgs = imgs;
        this.pcodes = pcodes;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.project_row, parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        byte[] imageAsBytes = Base64.decode(imgs[position].getBytes(), Base64.DEFAULT);
        holder.ivProject.setImageBitmap(BitmapFactory.decodeByteArray(imageAsBytes,0,imageAsBytes.length));
        holder.tvProject.setText(data[position]);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(context, ChatActivity.class);
                in.putExtra("pname",data[holder.getAdapterPosition()]);
                in.putExtra("pcode",pcodes[holder.getAdapterPosition()]);
                context.startActivity(in);
            }
        });
    }

    @Override
    public int getItemCount() {
        return data.length;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvProject;
        ImageView ivProject;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            tvProject = itemView.findViewById(R.id.tvProject);
            ivProject = itemView.findViewById(R.id.ivProject);
        }
    }
}
