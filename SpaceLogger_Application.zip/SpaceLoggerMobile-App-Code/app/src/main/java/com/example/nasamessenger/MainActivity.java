package com.example.nasamessenger;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class MainActivity extends AppCompatActivity {

    EditText etUserName, etPassword;
    ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);

        dialog = new ProgressDialog(this);
        dialog.setMessage("Checking User Credentials.....");
        dialog.setCancelable(false);

        etUserName = (EditText) findViewById(R.id.etUserName);
        etPassword = (EditText) findViewById(R.id.etPassword);
    }

    public void doLogin(View v) {
        //Toast.makeText(getApplicationContext(), "Login", Toast.LENGTH_LONG).show();
        String suser = etUserName.getText().toString();
        String spass = etPassword.getText().toString();

        dialog.show();
        String url = "http://10.0.2.2/nasa/checklogin.php?Text1=" + suser +
                "&Text2=" + spass +
                "&Submit1=submit";

        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();
                String ss[] = response.split(":");
                int res = Integer.parseInt(ss[0]);
                if(res != 0) {
                    //Toast.makeText(getApplicationContext(), "Login In", Toast.LENGTH_LONG).show();
                    Global.employeeCode = res;
                    Global.employeeName = ss[1];
                    Intent in = new Intent(getApplicationContext(), ProjectActivity.class);
                    startActivity(in);
                } else {
                    Global.employeeCode = 0;
                    Toast.makeText(getApplicationContext(), "Error in User Name/Password", Toast.LENGTH_LONG).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
            }
        });
        queue.add(request);
    }

    public void doNewSignup(View v) {
        Intent in = new Intent(this, RegistrationActivity.class);
        startActivity(in);
    }
}