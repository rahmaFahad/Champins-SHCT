package com.example.nasamessenger;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.nasamessenger.databinding.ItemReceiveBinding;
import com.example.nasamessenger.databinding.ItemSendBinding;

import java.util.ArrayList;

public class ChatAdapter extends RecyclerView.Adapter {
    Context context;
    ArrayList<Message> messageArrayList;

    final int ITEM_SENT = 1;
    final int ITEM_RECEIVE = 2;

    public ChatAdapter (Context context, ArrayList<Message> messageArrayList) {
        this.context = context;
        this.messageArrayList = messageArrayList;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Message message = messageArrayList.get(position);

        if(getItemViewType(position)==ITEM_SENT) {
            SenderViewHolder viewHolder = (SenderViewHolder) holder;
            viewHolder.binding.message.setText(message.getMessage());
            viewHolder.binding.tvMyTime.setText(message.getDate_time());
        } else {
            ReceiverViewHolder viewHolder = (ReceiverViewHolder) holder;
            viewHolder.binding.tvSender.setText(message.getUser_name());
            viewHolder.binding.tvTime.setText(message.getDate_time());
            viewHolder.binding.message.setText(message.getMessage());
        }
    }

    @Override
    public int getItemViewType(int position) {
        Message message = messageArrayList.get(position);
        if(message.getEmployee_code().equals(Global.employeeCode+"")) {
            return ITEM_SENT;
        } else {
            return ITEM_RECEIVE;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //Toast.makeText(context, "value:"+viewType, Toast.LENGTH_SHORT).show();
        if (viewType == ITEM_SENT) {
            View view = LayoutInflater.from(context).inflate(R.layout.item_send, parent, false);
            return new SenderViewHolder(view);
        } else {
            View view = LayoutInflater.from(context).inflate(R.layout.item_receive, parent, false);
            return new ReceiverViewHolder(view);
        }
    }

    @Override
    public int getItemCount() {
        return messageArrayList.size();
    }

    public class SenderViewHolder extends RecyclerView.ViewHolder {
        ItemSendBinding binding;
        public SenderViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ItemSendBinding.bind(itemView);
        }
    }

    public class ReceiverViewHolder extends RecyclerView.ViewHolder {
        ItemReceiveBinding binding;
        public ReceiverViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ItemReceiveBinding.bind(itemView);
        }
    }
}
