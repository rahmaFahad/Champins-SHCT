<?php
include 'connect.php';

$val1 = $_GET['Text1'];
$val2 = $_GET['Text2'];
$val3 = $_GET['Text3'];
$val4 = $_GET['Text4'];
$val5 = $_GET['Text5'];


$sql = "INSERT INTO lvmdb VALUES ('$val1', '$val2', '$val3', '$val4', '$val5')";

if (mysqli_query($conn, $sql)) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>