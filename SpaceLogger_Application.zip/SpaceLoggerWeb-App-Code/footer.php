<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
a:link {
	color: #0000FF;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
	text-align: left;
}

.n {
	text-align: right;
	font-weight: bold;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #960;
}
.banr {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
}
.banr {
	font-size: 12px;
}
.footer {
	color: #FFFFFF;
	text-align: center;
}
.foo {
	font-style: italic;
}
</style>
</head>

<body>
<table width="850" border="0" align="center" cellpadding="0" cellspacing="0" class="banr">
  <tr>
    <td  class="footer"><span class="foo"><font color="white">Copyright &copy;2021. UTAS-Shinas.</font></span></td>
  </tr>
</table>
</body>
</html>