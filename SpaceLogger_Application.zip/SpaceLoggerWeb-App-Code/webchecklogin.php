<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.aloginForm {
	font-size: 24px;
	font-weight: bold;
	font-family: Book Antiqua;
	color: #006;
	text-align: left;
}
.fg {text-align: right;
	font-family: Times New Roman;
	font-size: 14px;
	font-style: italic;
}
.auto-style6 {
	border-color: #00F;
	border-width: 0;
	background-color:#00FFCC;
}
.auto-style7 {
	font-family: "Times New Roman";
	font-weight: bold;
	font-size: 14px;
	color: #000080;
}
.auto-style8 {
	font-size: 24px;
	font-weight: bold;
	font-family: Book Antiqua;
	color: #006;
	text-align: center;
}
.auto-style10 {
	text-align: center;
}
.tb-style{
	border:2px solid #456879;
	border-radius:10px;
	height: 22px;
	width: 230px;
}
.body-bgstyle{
	background-image:url('Pictures/bg_img.jpg');
  	background-repeat: no-repeat;  	
  	background-size: cover;	
  	min-height: 100%;
  	min-width: 100%;
}
</style>
</head>


<body class="body-bgstyle">

<?php 
include("connect.php");

include('Banner.php');

echo "<table width='850' border='0' align='center'> <tr><td><center>";


$uname=$_POST['uname'];
$pword=$_POST['pword'];

$query="select * from lvmdb where Employee_code = '$uname' and Password = '$pword'";

//run the query
mysqli_query($conn,$query)or die("Error in query:$query".mysqli_error($con));
$result = mysqli_query($conn, $query);

$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
$count = mysqli_num_rows($result);

if($count == 1){
	//$_SESSION['uname']=$row['User_Name'];
	header("location:viewprojects.php");
}
else{
	echo "<h2><font color='red'>Invalid username or password..</font></h2>";
	echo "<br/><br/><a href='signin.php'><b>Sign in</b></a><br/><br/>";
}

echo "</center></td></tr></table>";


include('footer.php');

?>

</body>
</html>