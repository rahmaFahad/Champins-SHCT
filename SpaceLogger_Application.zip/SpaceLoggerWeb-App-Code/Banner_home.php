<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Untitled 1</title>
<style type="text/css">
a:link {
	color: aqua;
	text-decoration: none;
}
a:visited {
	color: aqua;
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	color: lime;
	text-decoration: none;
	text-align: left;
}

.n {
	text-align: right;
	font-weight: bold;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #960;
}
.banr {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
}
.banr {
	font-size: 12px;
}
.banr tr td {
	color: #003;
	font-family: Arial, Helvetica, sans-serif;
}
.auto-style1 {
	color: #FFFFFF;
}
</style>
</head>

<body>
<table width="850" border="0" align="center" cellpadding="0" cellspacing="0" class="banr">
  <tr>
    <td style="width: 578px; height: 22px;"><font color="#FF00FF"><a href="homepage.php">HOME</a> || <a href="aboutus.php">About Us</a> || <a href="contactus.php">Contact Us</a></font></td>
    <td class="banr" style="width: 264px; height: 22px;" align="right"><font color="#FF00FF"><a href="Homepage.php">Logout</a></font></td>
  </tr>
  <tr>
    <td colspan="2" align="center"><img src="Pictures/banner_img.jpg" height="150" width="850"/></td>
  </tr>
  <tr>
    <td colspan="2" ><strong><font color="#FFFF66"><b><marquee behavior="scroll" direction="left" scrollamount="10"><h3>NASA LIVE MESSENGER</h3></marquee></b></font></strong></td>
  </tr>
</table>
</body>
</html>
