<?php
include 'connect.php';

$val1 = $_GET['Text1'];
//$val2 = $_GET['Text2'];

$sql = "SELECT * FROM lvmdb, projecttranstable WHERE lvmdb.Employee_Code = projecttranstable.employee_code AND project_code = '$val1' ORDER BY date_time";
//$sql = "SELECT * FROM projecttranstable WHERE project_code = '$val1' ORDER BY date_time";
//$sql1 = "SELECT User_Name FROM lvmdb WHERE Employee_code = '$val2'"; 

$i=0;
$result = mysqli_query($conn, $sql);
$res = array();

//$eresult = mysqli_query($conn, $sql1);
//$eres = array();
//$erow = mysqli_fetch_assoc($eresult);
//array_push($eres, array('User_Name' => $erow['User_Name']));

if(mysqli_num_rows($result) > 0) {
	while($row = mysqli_fetch_assoc($result)) {
		array_push($res, array('User_Name' => $row['User_Name'], 'message_id' => $row['message_id'], 'date_time' => $row['date_time'], 'employee_code' => $row['employee_code'], 'project_code' => $row['project_code'], 'message' => $row['message'], 'message_type' => $row['message_type']));
	}
	echo json_encode(array("res" => $res));
} else {
	echo 0;
}

mysqli_close($conn);
?>