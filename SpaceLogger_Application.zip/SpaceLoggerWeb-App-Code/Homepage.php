<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.aloginForm {
	font-size: 24px;
	font-weight: bold;
	font-family: Book Antiqua;
	color: #006;
	text-align: left;
}
.fg {text-align: right;
	font-family: Times New Roman;
	font-size: 14px;
	font-style: italic;
}
.auto-style10 {
	text-align: center;
}
.tb-style{
	border:2px solid #456879;
	border-radius:10px;
	height: 22px;
	width: 230px;
}
.body-bgstyle{
	background-image:url('Pictures/bg_img.jpg');
  	background-repeat: no-repeat;  	
  	background-size: cover;	
  	min-height: 100%;
  	min-width: 100%;
}
.auto-style11 {
	color: #EFF3F3;
	font-family: Cambria, Cochin, Georgia, Times, "Times New Roman", serif;
	font-size: small;
}
</style>
</head>

<body class="body-bgstyle">
<?php
include('Banner.php');
?>
<br />
<table width="850" border="0" align="center" cellpadding="0" cellspacing="0">
<tr><td>
 <form id="form1" name="form1" method="post" action="">
  <div width="700" height="221" align="justify">
  	  <span class="auto-style11">During the Artemis lunar missions a very broad community will be following the lunar surface EVAs (Extravehicular Activities) or spacewalks. 
  	Throughout these EVAs crewmembers will be taking photographs, audibly describing what they see, and collecting samples to help answer some of 
  	the biggest mysteries regarding the Moon, Earth, and our solar system.
      </span>
    <br/><br/>
      <span class="auto-style11">Many people on Earth will be involved in documenting and reviewing this information in real time in addition to the post-mission operations debriefs
    and scientific research. In the current record-keeping approach implemented for human spaceflight, each flight control team member creates and
    maintains a console log to record the information necessary to support his/her job duties. This console log becomes part of the official record of 
    the mission. (See video for an example excerpt of a console log written from the perspective of EVA TASK when a crew performed a PGT operation.) 
    Using this present-day system, each flight control team member creates a console log in isolation. In other words, there is no way for a flight 
    controller to simultaneously see the live creation of logs by others or to synchronize multiple people's logs to compare notes with different 
    authors during or after a mission.
  </span>
  </div>
  
 </form>
</td></tr>
</table><br/><br/>
<?php
include('footer.php');
?>
<p class="auto-style10">&nbsp;</p>
</body>
</html>