<?php
include 'connect.php';

$val1 = $_GET['Text1'];
$val2 = $_GET['Text2'];

$sql = "SELECT Employee_code,User_Name FROM lvmdb WHERE Employee_code='$val1' AND Password='$val2'";

$result = mysqli_query($conn, $sql);
if(mysqli_num_rows($result) > 0) {
	$row = mysqli_fetch_assoc($result);
	echo $row["Employee_code"] . ":" . $row["User_Name"];
} else {
	echo mysqli_num_rows($result);
}

mysqli_close($conn);
?>