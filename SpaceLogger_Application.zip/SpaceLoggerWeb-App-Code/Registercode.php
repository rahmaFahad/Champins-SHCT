<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Untitled 1</title>
<style type="text/css">
.body-bgstyle{
	background-image:url('Pictures/bg_img.jpg');
  	background-repeat: no-repeat;  	
  	background-size: cover;	
  	min-height: 100%;
  	min-width: 100%;
}
</style>
</head>

<body class="body-bgstyle">

<?php 
include("connect.php");

include('Banner.php');

$uname=$_POST['uname'];
$pword=$_POST['pword'];
$email=$_POST['email'];
$ecode=$_POST['ecode'];
$mobileno=$_POST['mobileno'];

$query="insert into lvmdb values('$ecode','$uname','$pword','$email','$mobileno')";

//run the query
mysqli_query($conn,$query)or die("Error in query:$query".mysqli_error($conn));

echo "<table width='850' border='0' align='center'> <tr><td>";

echo "<center><font color='#CCFFFF'><br><h2>Successfully registered in the website. The registration details are as follows</h2><br>";

echo "<h1> Registration Details</h1>";
echo "Employee Code: $ecode<br>";
echo "User Name: $uname<br>";
echo "Email ID: $email<br>";
echo "Mobile Number: $mobileno<br><br>";

echo "<a href='signin.php'><b>Sign in</b></a><br/><br/>";
echo "</font></center></td></tr></table>";

include('footer.php');

?>

</body>

</html>
