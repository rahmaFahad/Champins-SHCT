<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.aloginForm {
	font-size: 24px;
	font-weight: bold;
	font-family: Book Antiqua;
	color: #006;
	text-align: left;
}
.fg {text-align: right;
	font-family: Times New Roman;
	font-size: 14px;
	font-style: italic;
}
.auto-style6 {
	border-color: #00F;
	border-width: 0;
	background-color:#00FFCC;
}
.auto-style8 {
	font-size: 24px;
	font-weight: bold;
	font-family: Book Antiqua;
	color: #006;
	text-align: center;
}
.auto-style10 {
	text-align: center;
}
.tb-style{
	border:2px solid #456879;
	border-radius:10px;
	height: 22px;
	width: 230px;
}
.body-bgstyle{
	background-image:url('Pictures/bg_img.jpg');
  	background-repeat: no-repeat;  	
  	background-size: cover;	
  	min-height: 100%;
  	min-width: 100%;
}
.div-style1 {
	font-family: "Courier New", Courier, monospace;
	font-size: medium;
	border-style: solid;
	border-width: 1px;
	padding: 1px 4px;
	border-color:#000066;
	background-color:#6699FF;
}

</style>
</head>

<body class="body-bgstyle">
<?php
include('Banner_home.php');

include("connect.php");
?>
<br />

<?php

$pcode=$_GET['pcode'];

$query="select * from projectMasterTable where Project_Code='$pcode'";

$result=mysqli_query($conn,$query);

while($row = mysqli_fetch_assoc($result)) {
  
$pcodee=$row['Project_code'];
$pname=$row['Project_Name'];
$pdes=$row['Project_Description'];

}
?>


<table width="850" border="0" align="center" cellpadding="0" cellspacing="0" >
<tr><td>
    
	<table align="center" style="width: 80%; height: 30px">
	
	<tr>
	<td><font color="#CCFFFF"> Project Code : <?php echo $pcodee; ?></font></td>
	</tr>
	<tr>
	<td><font color="#CCFFFF"> Project Name : <?php echo $pname ?> </font></td>
	</tr>
	<tr>
	<td><font color="#CCFFFF"> Project Description : <?php echo $pdes ?> </font></td>
	</tr>
	<tr>
	<td><div class="div-style1">
	

	<?php
		$query1="select * from projectTransTable where Project_Code='$pcode' ORDER BY date_time";
		//query1="select * from projectMasterTable,projectTransTable where projectMasterTable.Project_Code=projecttranstable.Project_Code AND projectmastertable.Project_Code = $pcode";
		$res=mysqli_query($conn,$query1);

		while($row1=mysqli_fetch_assoc($res))
		{
			$dt=$row1['date_time'];
			$ecode=$row1['employee_code'];
			$msg=$row1['message'];
 			
 			echo"<font color='#CCFFFF'><br/>$ecode : $dt <br/>";
 			echo"$msg<br/></font>";

		}
	?>
	</div></td></tr>
	</table>
</td></tr>
</table>

<br/><br/><br/>
<?php
include('footer.php');
?>
<p class="auto-style10">&nbsp;</p>
</body>
</html>
