<?php
include 'connect.php';

$sql = "SELECT Project_Name, Project_Image, Project_code FROM projectmastertable";

$i=0;
$result = mysqli_query($conn, $sql);
$res = array();

	while($row = mysqli_fetch_assoc($result)) {
		array_push($res, array('Project_Name' => $row['Project_Name'], 'Project_Image' => $row['Project_Image'], 'Project_code' => $row['Project_code']));
		//$parr[$i] = $row["Project_Name"];
		//$i++;
	}
	echo json_encode(array("res" => $res));

mysqli_close($conn);
?>