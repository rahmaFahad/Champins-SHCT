<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.aloginForm {
	font-size: 24px;
	font-weight: bold;
	font-family: Book Antiqua;
	color: #006;
	text-align: left;
}
.fg {text-align: right;
	font-family: Times New Roman;
	font-size: 14px;
	font-style: italic;
}
.auto-style6 {
	border-color: #00F;
	border-width: 0;
	background-color:#00FFCC;
}
.auto-style8 {
	font-size: 24px;
	font-weight: bold;
	font-family: Book Antiqua;
	color: #006;
	text-align: center;
}
.auto-style10 {
	text-align: center;
}
.tb-style{
	border:2px solid #456879;
	border-radius:10px;
	height: 22px;
	width: 230px;
}
.body-bgstyle{
	background-image:url('Pictures/bg_img.jpg');
  	background-repeat: no-repeat;  	
  	background-size: cover;	
  	min-height: 100%;
  	min-width: 100%;
}
</style>
</head>

<body class="body-bgstyle">
<?php
include('Banner.php');
?>
<br />
<table width="850" border="0" align="center" cellpadding="0" cellspacing="0" >
<tr><td>
 <form id="form1" name="form1" method="post" action="Registercode.php">
  <table width="475" height="221" align="center" cellpadding="0" cellspacing="5"  style="text-align: center;" class="auto-style6">
    <tr>
      <td bgcolor="#FFFFFF" class="auto-style8">Registration</td>
    </tr>
    <tr>
    	<td></td>
    </tr>
    <tr>
      <td><input type="text" name="uname" id="uname" style="width: 200px"  required="required" maxlength="25" placeholder="USERNAME" class="tb-style"/></td>
    </tr>
    <tr>
      <td><span style="text-align: left"><input type="password" name="pword" id="pword" style="width: 200px" required="required" maxlength="10" placeholder="PASSWORD" class="tb-style"/></span></td>
    </tr>
    <tr>
      <td><span style="text-align: left"><input type="text" name="email" id="email" style="width: 200px" required="required" maxlength="30" placeholder="Email Address" class="tb-style"/></span></td>
    </tr>
	<tr>
      <td><span style="text-align: left"><input type="text" name="ecode" id="ecode" style="width: 200px" required="required" maxlength="30" placeholder="Employee Code" class="tb-style"/></span></td>
    </tr>
    <tr>
      <td><span style="text-align: left"><input type="text" name="mobileno" id="mobileno" style="width: 200px" required="required" maxlength="12" placeholder="Mobile Number" class="tb-style"/></span></td>
    </tr>
    <tr>
      <td height="36"><input type="submit" name="submit" value="SIGN UP" /> <input type="reset" name="reset" value="CANCEL" /></td>
    </tr>
  </table>  
 </form>
</td></tr>
</table>
<br/>
<?php
include('footer.php');
?>
<p class="auto-style10">&nbsp;</p>
</body>
</html>