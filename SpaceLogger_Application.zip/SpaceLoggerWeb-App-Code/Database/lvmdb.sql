-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 29, 2021 at 11:46 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lvmdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `projectmastertable`
--

DROP TABLE IF EXISTS `projectmastertable`;
CREATE TABLE IF NOT EXISTS `projectmastertable` (
  `Project_Code` int(11) NOT NULL,
  `Project_Name` text NOT NULL,
  `Project_Description` text NOT NULL,
  PRIMARY KEY (`Project_Code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `projectmastertable`
--

INSERT INTO `projectmastertable` (`Project_Code`, `Project_Name`, `Project_Description`) VALUES
(101, 'AP11', 'A real-time journey through the first landing on the Moon'),
(12, 'AP12', 'A real-time journey through the second lunar landing attempt.');

-- --------------------------------------------------------

--
-- Table structure for table `projecttranstable`
--

DROP TABLE IF EXISTS `projecttranstable`;
CREATE TABLE IF NOT EXISTS `projecttranstable` (
  `Message_ID` int(11) NOT NULL,
  `Date_Time` varchar(10) NOT NULL,
  `Employee_Code` int(11) NOT NULL,
  `Project_Code` int(11) NOT NULL,
  `Message` text NOT NULL,
  PRIMARY KEY (`Message_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `projecttranstable`
--

INSERT INTO `projecttranstable` (`Message_ID`, `Date_Time`, `Employee_Code`, `Project_Code`, `Message`) VALUES
(1, '2/2/2020', 11, 101, 'landed'),
(2, '3/2/2020', 11, 101, 'height 200000km');

-- --------------------------------------------------------

--
-- Table structure for table `usertable`
--

DROP TABLE IF EXISTS `usertable`;
CREATE TABLE IF NOT EXISTS `usertable` (
  `Employee_Code` int(11) NOT NULL,
  `User_Name` text NOT NULL,
  `Password` text NOT NULL,
  `Email` text NOT NULL,
  `Registered_Mobile Number` int(11) NOT NULL,
  PRIMARY KEY (`Employee_Code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usertable`
--

INSERT INTO `usertable` (`Employee_Code`, `User_Name`, `Password`, `Email`, `Registered_Mobile Number`) VALUES
(11, 'aa', 'aa', 'aa', 121),
(22, 'bb', 'bb', 'bb', 2121),
(1234, 'ad', 'ad', 'ad', 1234),
(55, 'anu', 'aaa', 'anu@gmail.com', 787878),
(99, 'kk', 'kk', 'kk', 99),
(33333, 'qq', 'qq', 'qq', 3333);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
